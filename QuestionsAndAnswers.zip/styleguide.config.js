{
  propsParser: require('react-docgen-typescript').withDefaultConfig().parse
}