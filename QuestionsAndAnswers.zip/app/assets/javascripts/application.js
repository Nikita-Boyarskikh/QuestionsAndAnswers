/*
 *= require i18n
 *= require turbolinks
 *= require jquery
 *
 * JQuery + Turboliks
 *= require jquery.turbolinks
 *
 *= require semantic-ui
 *= require react
 *= require react_ujs
 *= require components
 */
