class ApplicationMailer < ActionMailer::Base
  default from: 'N02@yandex.ru'
  layout 'mailer'
end
