require 'test_helper'

class AnswerTest < ActiveSupport::TestCase
end
