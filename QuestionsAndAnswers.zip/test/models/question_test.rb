require 'test_helper'

class QuestionTest < ActiveSupport::TestCase
end
