require 'test_helper'

class UserTest < ActiveSupport::TestCase
end
