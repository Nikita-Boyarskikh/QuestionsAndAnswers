require 'test_helper'

class AvatarTest < ActiveSupport::TestCase
end
