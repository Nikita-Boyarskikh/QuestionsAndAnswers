require 'test_helper'

class LikeTest < ActiveSupport::TestCase
end
