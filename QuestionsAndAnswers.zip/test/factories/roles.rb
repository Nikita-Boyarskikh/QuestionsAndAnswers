FactoryBot.define do
  factory :role do
    
  end
end
