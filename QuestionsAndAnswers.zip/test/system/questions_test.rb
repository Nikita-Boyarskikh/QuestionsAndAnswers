require 'application_system_test_case'

class QuestionsTest < ApplicationSystemTestCase
end
