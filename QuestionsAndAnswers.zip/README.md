# Questions-and-answers-Ruby
Replica of exists project but on Ruby on Rails https://github.com/Nikita-Boyarskikh/Questions-And-Answers 

TODOs:
* Wiki
* Readme
* etc
